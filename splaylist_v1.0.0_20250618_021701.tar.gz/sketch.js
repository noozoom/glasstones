// GlassTones sketch.js 

let lines = []; // Array to store drawn lines
let ball = {}; // Single ball object
let backgroundImg; // Background advertisement image
let gameStarted = false;

// Line properties
const MAX_LINES = 8;
const LINE_LIFETIME = 6000; // 6 seconds in milliseconds
const MAX_LINE_LENGTH = 200; // Maximum points per line

// Ball properties
const BALL_SIZE = 15;
const BALL_SPEED = 1.5;

// Current drawing line
let currentLine = null;
let isDrawing = false;

function setup() {
    // Create canvas that fills the window and store reference
    const cnv = createCanvas(windowWidth, windowHeight);
    
    console.log('Canvas created:', windowWidth, 'x', windowHeight);
    console.log('Width/Height:', width, 'x', height);
    
    // Initialize ball
    initializeBall();
    
    // Start the game
    gameStarted = true;
    
    // Initialize score display
    if (typeof initializeScore === 'function') {
        initializeScore();
    }
    
    // Initialize audio context on user interaction (attach to actual canvas element)
    cnv.canvas.addEventListener('touchstart', handleUserInteraction);
    cnv.canvas.addEventListener('mousedown', handleUserInteraction);
    
    console.log('Setup complete');
}

function draw() {
    // Simple purple background
    background(150, 50, 150);
    
    // Update and draw all lines
    updateLines();
    drawLines();
    
    // Update and draw ball
    updateBall();
    drawBall();
    
    // Draw ball trail effect
    drawBallTrail();
    
    // Debug: Draw a white border to see canvas bounds
    stroke(255);
    strokeWeight(2);
    noFill();
    rect(1, 1, width-2, height-2);
}

function createBackgroundImage() {
    // Simplified - no longer needed
    console.log('Background function called but simplified');
}

function drawBackground() {
    // Simplified - just use background() in draw()
    background(150, 50, 150);
}

function initializeBall() {
    ball = {
        x: width / 2,
        y: height / 2,
        vx: random(-BALL_SPEED, BALL_SPEED),
        vy: random(-BALL_SPEED, BALL_SPEED),
        trail: [] // Array to store trail positions
    };
    
    // Ensure minimum speed
    if (Math.abs(ball.vx) < 0.5) ball.vx = ball.vx < 0 ? -0.5 : 0.5;
    if (Math.abs(ball.vy) < 0.5) ball.vy = ball.vy < 0 ? -0.5 : 0.5;
}

function updateBall() {
    // Store current position for trail
    ball.trail.push({x: ball.x, y: ball.y});
    
    // Limit trail length
    if (ball.trail.length > 20) {
        ball.trail.shift();
    }
    
    // Move ball
    ball.x += ball.vx;
    ball.y += ball.vy;
    
    // Bounce off walls
    if (ball.x - BALL_SIZE/2 <= 0 || ball.x + BALL_SIZE/2 >= width) {
        ball.vx *= -1;
        ball.x = Math.max(BALL_SIZE/2, Math.min(ball.x, width - BALL_SIZE/2));
    }
    if (ball.y - BALL_SIZE/2 <= 0 || ball.y + BALL_SIZE/2 >= height) {
        ball.vy *= -1;
        ball.y = Math.max(BALL_SIZE/2, Math.min(ball.y, height - BALL_SIZE/2));
    }
    
    // Check collision with lines
    checkLineCollisions();
}

function drawBall() {
    // Draw ball with glow effect
    push();
    
    // Outer glow
    for (let i = 3; i > 0; i--) {
        fill(255, 255, 255, 30 * i);
        noStroke();
        ellipse(ball.x, ball.y, BALL_SIZE + i * 4);
    }
    
    // Main ball
    fill(255, 255, 255, 200);
    noStroke();
    ellipse(ball.x, ball.y, BALL_SIZE);
    
    // Inner highlight
    fill(255, 255, 255, 100);
    ellipse(ball.x - 3, ball.y - 3, BALL_SIZE * 0.3);
    
    pop();
}

function drawBallTrail() {
    // Draw trail effect where ball reveals background
    push();
    
    for (let i = 0; i < ball.trail.length; i++) {
        let pos = ball.trail[i];
        let alpha = map(i, 0, ball.trail.length - 1, 0, 255);
        let size = map(i, 0, ball.trail.length - 1, BALL_SIZE * 0.3, BALL_SIZE * 2);
        
        // Create a revealing effect by drawing background image
        tint(255, alpha * 0.3);
        
        // This will be enhanced later with proper masking
        fill(255, 255, 255, 50);
        noStroke();
        ellipse(pos.x, pos.y, size);
    }
    
    noTint();
    pop();
}

function checkLineCollisions() {
    // This will be implemented when we add line collision detection
    // For now, just a placeholder
}

// Drawing functions
function mousePressed() {
    startDrawing(mouseX, mouseY);
}

function mouseDragged() {
    if (isDrawing) {
        addPointToCurrentLine(mouseX, mouseY);
    }
}

function mouseReleased() {
    endDrawing();
}

// Touch events for mobile
function touchStarted() {
    if (touches.length > 0) {
        startDrawing(touches[0].x, touches[0].y);
    }
    return false; // Prevent default
}

function touchMoved() {
    if (isDrawing && touches.length > 0) {
        addPointToCurrentLine(touches[0].x, touches[0].y);
    }
    return false; // Prevent default
}

function touchEnded() {
    endDrawing();
    return false; // Prevent default
}

function startDrawing(x, y) {
    isDrawing = true;
    currentLine = {
        points: [{x: x, y: y}],
        startTime: millis(),
        id: random(1000000) // Unique ID for scoring
    };
}

function addPointToCurrentLine(x, y) {
    if (!currentLine) return;
    
    let lastPoint = currentLine.points[currentLine.points.length - 1];
    let distance = dist(x, y, lastPoint.x, lastPoint.y);
    
    // Only add point if it's far enough from the last point
    if (distance > 3) {
        currentLine.points.push({x: x, y: y});
        
        // Limit line length
        if (currentLine.points.length > MAX_LINE_LENGTH) {
            currentLine.points.shift();
        }
    }
}

function endDrawing() {
    if (!isDrawing || !currentLine) return;
    
    isDrawing = false;
    
    // Only add line if it has enough points
    if (currentLine.points.length > 5) {
        lines.push(currentLine);
        
        // Remove oldest line if we have too many
        if (lines.length > MAX_LINES) {
            lines.shift();
        }
    }
    
    currentLine = null;
}

function updateLines() {
    let currentTime = millis();
    
    // Remove expired lines
    lines = lines.filter(line => {
        return currentTime - line.startTime < LINE_LIFETIME;
    });
}

function drawLines() {
    push();
    
    // Draw all completed lines
    for (let line of lines) {
        drawLine(line);
    }
    
    // Draw current line being drawn
    if (currentLine && currentLine.points.length > 1) {
        drawLine(currentLine);
    }
    
    pop();
}

function drawLine(line) {
    if (line.points.length < 2) return;
    
    let currentTime = millis();
    let age = currentTime - line.startTime;
    let alpha = map(age, 0, LINE_LIFETIME, 255, 0);
    alpha = Math.max(0, Math.min(alpha, 255));
    
    // Draw line with transparency effect
    stroke(255, 255, 255, alpha);
    strokeWeight(3);
    noFill();
    
    beginShape();
    for (let point of line.points) {
        vertex(point.x, point.y);
    }
    endShape();
    
    // Draw line with glow effect
    stroke(200, 200, 255, alpha * 0.5);
    strokeWeight(6);
    beginShape();
    for (let point of line.points) {
        vertex(point.x, point.y);
    }
    endShape();
}

function handleUserInteraction() {
    // Initialize audio context when user first interacts
    if (typeof initializeAudio === 'function') {
        initializeAudio();
    }
}

// Handle window resize
function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
    createBackgroundImage(); // Recreate background for new size
} 