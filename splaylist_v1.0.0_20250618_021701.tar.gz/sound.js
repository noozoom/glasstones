// GlassTones sound.js 

let audioInitialized = false;
let drone = null;
let synthPool = [];
const SYNTH_POOL_SIZE = 8;

// Phrygian scale frequencies (G2-G4)
const phrygianScale = [
    98.00,   // G2
    103.83,  // Ab2
    116.54,  // Bb2
    130.81,  // C3
    138.59,  // Db3
    155.56,  // Eb3
    174.61,  // F3
    196.00,  // G3
    207.65,  // Ab3
    233.08,  // Bb3
    261.63,  // C4
    277.18,  // Db4
    311.13,  // Eb4
    349.23,  // F4
    392.00   // G4
];

// Initialize audio system
function initializeAudio() {
    if (audioInitialized) return;
    
    try {
        // Start Tone.js context
        Tone.start().then(() => {
            console.log('Audio context started');
            setupDrone();
            setupSynthPool();
            audioInitialized = true;
        });
    } catch (error) {
        console.error('Failed to initialize audio:', error);
    }
}

// Setup the G2 drone bass
function setupDrone() {
    // Create drone synthesizer
    drone = new Tone.Oscillator({
        frequency: phrygianScale[0], // G2
        type: "sine",
        volume: -20 // Start quiet
    }).toDestination();
    
    // Create volume envelope for drone
    const droneGain = new Tone.Gain(0).toDestination();
    drone.connect(droneGain);
    
    // Start drone and fade in over 10 seconds
    drone.start();
    droneGain.gain.rampTo(0.3, 10); // 10 second attack
    
    // Store reference for game over fade out
    drone.gainNode = droneGain;
}

// Setup synthesizer pool for line sounds
function setupSynthPool() {
    synthPool = [];
    
    for (let i = 0; i < SYNTH_POOL_SIZE; i++) {
        const synth = new Tone.Synth({
            oscillator: {
                type: "sine"
            },
            envelope: {
                attack: 0.5,    // 0.5 second attack
                decay: 0.2,
                sustain: 0.3,
                release: 7      // 7 second release
            },
            volume: -15
        }).toDestination();
        
        synthPool.push({
            synth: synth,
            inUse: false,
            lastUsed: 0
        });
    }
}

// Get frequency based on line length
function getFrequencyFromLineLength(lineLength) {
    // Map line length to scale index
    // Shorter lines = higher pitch, longer lines = lower pitch
    const maxLength = width / 4; // Maximum expected line length
    const normalizedLength = Math.max(0, Math.min(lineLength / maxLength, 1));
    
    // Invert so shorter = higher pitch
    const invertedLength = 1 - normalizedLength;
    
    // Map to scale index (skip the first G2 which is for drone)
    const scaleIndex = Math.floor(invertedLength * (phrygianScale.length - 2)) + 1;
    const clampedIndex = Math.max(1, Math.min(scaleIndex, phrygianScale.length - 1));
    
    return phrygianScale[clampedIndex];
}

// Calculate line length from points
function calculateLineLength(linePoints) {
    if (linePoints.length < 2) return 0;
    
    let totalLength = 0;
    for (let i = 1; i < linePoints.length; i++) {
        let dx = linePoints[i].x - linePoints[i-1].x;
        let dy = linePoints[i].y - linePoints[i-1].y;
        totalLength += Math.sqrt(dx * dx + dy * dy);
    }
    
    return totalLength;
}

// Play sound when ball hits line
function playLineSound(line) {
    if (!audioInitialized) return;
    
    // Find available synth
    let availableSynth = null;
    let oldestTime = Infinity;
    let oldestIndex = 0;
    
    for (let i = 0; i < synthPool.length; i++) {
        if (!synthPool[i].inUse) {
            availableSynth = synthPool[i];
            break;
        } else if (synthPool[i].lastUsed < oldestTime) {
            oldestTime = synthPool[i].lastUsed;
            oldestIndex = i;
        }
    }
    
    // If no available synth, use the oldest one
    if (!availableSynth) {
        availableSynth = synthPool[oldestIndex];
        availableSynth.synth.triggerRelease(); // Stop current note
    }
    
    // Calculate frequency based on line length
    const lineLength = calculateLineLength(line.points);
    const frequency = getFrequencyFromLineLength(lineLength);
    
    // Play the note
    try {
        availableSynth.synth.triggerAttackRelease(frequency, "7"); // 7 second note
        availableSynth.inUse = true;
        availableSynth.lastUsed = millis();
        
        // Mark as not in use after the note finishes
        setTimeout(() => {
            availableSynth.inUse = false;
        }, 8000); // A bit longer than the note duration
        
        console.log(`Playing line sound: ${frequency.toFixed(2)} Hz`);
    } catch (error) {
        console.error('Failed to play line sound:', error);
    }
}

// Stop drone and fade out (for game over)
function stopDrone() {
    if (!audioInitialized || !drone) return;
    
    try {
        // Fade out over 10 seconds then stop
        drone.gainNode.gain.rampTo(0, 10);
        
        setTimeout(() => {
            if (drone) {
                drone.stop();
                drone.dispose();
                drone = null;
            }
        }, 10500); // Stop after fade completes
        
        console.log('Drone stopping...');
    } catch (error) {
        console.error('Failed to stop drone:', error);
    }
}

// Clean up audio resources
function cleanupAudio() {
    if (!audioInitialized) return;
    
    try {
        // Stop and dispose of all synths
        synthPool.forEach(item => {
            item.synth.dispose();
        });
        synthPool = [];
        
        // Stop drone
        stopDrone();
        
        audioInitialized = false;
        console.log('Audio cleaned up');
    } catch (error) {
        console.error('Failed to cleanup audio:', error);
    }
}

// Utility function to test audio
function testAudio() {
    if (!audioInitialized) {
        console.log('Audio not initialized');
        return;
    }
    
    // Play a test note
    const testLine = {
        points: [
            {x: 0, y: 0},
            {x: 100, y: 100}
        ]
    };
    
    playLineSound(testLine);
} 