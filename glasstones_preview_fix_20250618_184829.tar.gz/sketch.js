// GlassTones sketch.js 

// === 背景・曇りガラスエフェクト追加 (2025-06-18) ===
// 1) preload() で広告画像をロード
// 2) fogLayer (p5.Graphics) に白半透明レイヤーを保持し、erase() で透過
// 3) draw() 冒頭で広告を描画→ fogLayer で曇り → 以降ゲーム描画
// 4) Ball と Line 描画時に fogLayer をクリアして透過効果

let lines = []; // Array to store drawn lines
let points = []; // Array to store single-click points (hexagons)
let ball = {}; // Single ball object
let backgroundImg; // Background advertisement image
let fogLayer;      // Graphics layer for fog overlay
let draftLayer;    // Realtime preview layer (no fog interaction)
let gameStarted = false;

// Line properties
const MAX_LINES = 8;
const LINE_LIFETIME = 10000; // 10 seconds in milliseconds
const MAX_LINE_LENGTH = 200; // Maximum points per line

// Ball properties
const BALL_SIZE = 32; // 1.5x from previous size for more impact
const BALL_SPEED = 1.5;
const COLLISION_RADIUS = BALL_SIZE / 2 + 12; // Keep same padding

// === デバイス判定 & パラメータ自動調整 ===
const IS_MOBILE = /iP(hone|ad|od)|Android/.test(navigator.userAgent);
const FPS              = IS_MOBILE ? 30 : 45;
// 85% 不透明程度 (≈217)
const FOG_INITIAL_ALPHA = IS_MOBILE ? 200 : 210; // Much stronger initial fog for both
// Adjust fog recovery constants
const REFOG_ALPHA       = IS_MOBILE ? 12 : 14; // Match initial fog density
const REFOG_INTERVAL    = 3; // Refog every 3 frames (1.5x longer transparent phase)

// Line visual sizes
const LINE_MAIN_WEIGHT  = IS_MOBILE ? 46 : 47; // Mobile: 20% smaller (58*0.8≈46)
const LINE_GLOW_WEIGHT  = LINE_MAIN_WEIGHT * 1.5; // proportional glow

// Point properties (hexagon points) - defined after LINE_MAIN_WEIGHT
const MAX_POINTS = 12; // Maximum number of points
const POINT_LIFETIME = 15000; // 15 seconds in milliseconds
const POINT_RADIUS = LINE_MAIN_WEIGHT * 0.575; // 15% larger than line width (diameter = 115% of line width)

// Current drawing line
let currentLine = null;
let isDrawing = false;

// Consecutive hit tracking for octave scaling
let lastHitLineIndex = -1;
let consecutiveHits = 0;
let lastHitTime = 0;

let lastNoteName = "";
let lastLineLen = 0;
let lastFreq = 0;
let lastInfoTime = 0;

// Pixel-density scaling (CSS px を基準にする)
let PD_SCALE = 1; // set in setup()

// Add after existing const declarations near the top
const DEBUG = false; // Set to true for development logging

// Add constant near other const declarations
const TRAIL_TAPER_INTENSITY = 0.3; // 0 (old) - 1 (full comet taper)

// Add new constant near fog clear const
const LINE_ERASE_ALPHA = 200; // 0=fully clear, 255=no clear; 200 means ~80% clear

// Add new constant near fog clear const
const FOG_CLEAR_MULT = 1.0; // use exact line width for clearing

// Add particle system variables
let particles = []; // Array to store collision particles

// Add particle class
class CollisionParticle {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.vx = random(-3, 3);
        this.vy = random(-3, 3);
        this.life = 6000; // 6 seconds
        this.maxLife = 6000;
        this.size = IS_MOBILE ? random(2, 5) : random(8, 20); // Mobile: quarter size
        this.startTime = millis();
    }

    update() {
        this.x += this.vx;
        this.y += this.vy;
        this.vx *= 0.98; // slight friction
        this.vy *= 0.98;
        this.life = this.maxLife - (millis() - this.startTime);
        return this.life > 0;
    }

    draw() {
        let alpha = map(this.life, 0, this.maxLife, 0, 150);
        let currentSize = map(this.life, 0, this.maxLife, 2, this.size);
        
        // Clear fog around particle
        fogLayer.erase(255, alpha);
        fogLayer.ellipse(this.x, this.y, currentSize);
        fogLayer.noErase();
    }
}

// Add particles creation on collision
function createCollisionParticles(x, y) {
    for (let i = 0; i < 8; i++) {
        particles.push(new CollisionParticle(x, y));
    }
}

// Update particles in draw()
function updateParticles() {
    for (let i = particles.length - 1; i >= 0; i--) {
        if (!particles[i].update()) {
            particles.splice(i, 1);
        } else {
            particles[i].draw();
        }
    }
}

// -----------------------------
// p5 preload : 広告画像を読み込み
// -----------------------------
function preload() {
    backgroundImg = loadImage('assets/shiseido_mizuhara.png', () => {
        console.log('Shiseido background loaded successfully');
    }, err => {
        console.error('Shiseido background load failed, loading fallback');
        backgroundImg = loadImage('assets/027_01.jpg');
    });
}

function setup() {
    // Mobile 向けはピクセル密度を 1 にして負荷を軽減
    if (IS_MOBILE) {
        pixelDensity(1);
    }
    // Create canvas that fills the window
    createCanvas(windowWidth, windowHeight);
    
    console.log('Canvas created:', windowWidth, 'x', windowHeight);
    console.log('Width/Height:', width, 'x', height);
    console.log('p5.js functions available:', typeof background, typeof ellipse, typeof rect);
    
    // Create fog overlay
    fogLayer = createGraphics(windowWidth, windowHeight);
    fogLayer.noStroke();
    fogLayer.background(230, 230, 230, FOG_INITIAL_ALPHA); // 10% darker fog
    
    // Create draft layer (transparent)
    draftLayer = createGraphics(windowWidth, windowHeight);
    draftLayer.clear();
    
    // Initialize ball
    initializeBall();
    
    // Start the game
    gameStarted = true;
    
    // Initialize score display
    if (typeof initializeScore === 'function') {
        initializeScore();
    }
    
    // Test note display
    setTimeout(() => {
        let noteEl = document.getElementById('note-display');
        if (noteEl) {
            noteEl.textContent = ''; // テキストをクリアして非表示にする
            noteEl.style.display = 'none';
            console.log('Note display element found and cleared');
        } else {
            console.error('Note display element not found');
        }
    }, 1000);
    
    console.log('Setup complete');
    
    frameRate(FPS); // Cap FPS for mobile performance
    
    // 取得した pixelDensity でスケールを決定
    PD_SCALE = 1 / pixelDensity();
}

function draw() {
    // Replace the draw function debug log condition
    if (DEBUG && frameCount % 60 === 0) { // Log only when DEBUG is true
        console.log('Draw function called, frame:', frameCount);
    }
    
    // ---------- 背景広告を描画（縦横比保持でカバー） ----------
    if (backgroundImg) {
        // Calculate scale to cover entire screen while maintaining aspect ratio
        let scaleX = width / backgroundImg.width;
        let scaleY = height / backgroundImg.height;
        let scale = Math.max(scaleX, scaleY); // Use larger scale to cover
        
        let scaledWidth = backgroundImg.width * scale;
        let scaledHeight = backgroundImg.height * scale;
        
        // Center the image
        let offsetX = (width - scaledWidth) / 2;
        let offsetY = (height - scaledHeight) / 2;
        
        image(backgroundImg, offsetX, offsetY, scaledWidth, scaledHeight);
    } else {
        background(200);
    }

    // ---------- フォグレイヤーの徐々に再曇り処理 ----------
    // パフォーマンス最適化：4 フレームに 1 回だけ上塗り
    if (gameStarted && frameCount % REFOG_INTERVAL === 0) {
        // 霧の回復は削られた部分のみ、元の霧レベルを超えないように
        fogLayer.fill(230, 230, 230, 3); // 非常に薄い霧で徐々に回復
        fogLayer.rect(0, 0, width, height);
    }

    // Update and draw all lines
    updateLines();
    drawLines();
    
    // Update & draw ball + trail (これらで fogLayer を消去する)
    updateBall();
    drawBallTrail(); // 先に trail で透過
    drawBall();

    // ---------- フォグレイヤーをキャンバスに重ねる ----------
    image(fogLayer, 0, 0);

    // --- realtime preview layer on top of fog ---
    
    // Draw preview line if currently drawing
    if (currentLine && currentLine.points.length > 1) {
        console.log('Drawing preview, points:', currentLine.points.length);
        drawPreviewLineDirectly(currentLine);
    } else {
        // 描画していない時はプレビューレイヤーをクリア
        draftLayer.clear();
    }
    
    // Always draw draftLayer (even if empty)
    image(draftLayer, 0, 0);

    // Update particles
    updateParticles();
}

function createBackgroundImage() {
    // Simplified - no longer needed
    console.log('Background function called but simplified');
}

function drawBackground() {
    // Simplified - just use background() in draw()
    background(150, 50, 150);
}

function initializeBall() {
    ball = {
        x: width / 2,
        y: height / 2,
        vx: random(-BALL_SPEED, BALL_SPEED),
        vy: random(-BALL_SPEED, BALL_SPEED),
        trail: [] // Array to store trail positions
    };
    
    // Ensure minimum speed
    if (Math.abs(ball.vx) < 0.5) ball.vx = ball.vx < 0 ? -0.5 : 0.5;
    if (Math.abs(ball.vy) < 0.5) ball.vy = ball.vy < 0 ? -0.5 : 0.5;
}

function updateBall() {
    // Store previous position before moving
    let prevX = ball.x;
    let prevY = ball.y;
    
    // Store current position for trail
    ball.trail.push({x: ball.x, y: ball.y});
    
    // Limit trail length (10 seconds at 60fps = 600 frames)
    if (ball.trail.length > 600) {
        ball.trail.shift();
    }
    
    // Move ball
    ball.x += ball.vx;
    ball.y += ball.vy;
    
    // Bounce off walls
    if (ball.x - BALL_SIZE/2 <= 0 || ball.x + BALL_SIZE/2 >= width) {
        ball.vx *= -1;
        ball.x = Math.max(BALL_SIZE/2, Math.min(ball.x, width - BALL_SIZE/2));
    }
    if (ball.y - BALL_SIZE/2 <= 0 || ball.y + BALL_SIZE/2 >= height) {
        ball.vy *= -1;
        ball.y = Math.max(BALL_SIZE/2, Math.min(ball.y, height - BALL_SIZE/2));
    }
    
    // Check collision with lines (with tunneling prevention)
    checkLineCollisions(prevX, prevY);

    // Update drone panning to follow ball
    if (typeof updateDronePan === 'function') {
        updateDronePan(ball.x);
    }
}

function drawBall() {
    // Draw ball with glow effect
    push();
    
    // 生きているような明るさの揺らぎ
    const breathe = sin(millis() * 0.003) * 0.3 + 0.7; // 0.4〜1.0
    const pulse = sin(millis() * 0.008) * 0.2 + 0.8;   // 0.6〜1.0
    const glow = breathe * pulse;
    
    // 多層グロー効果（この世界で最も明るい存在）
    for (let i = 8; i > 0; i--) {
        const alpha = map(i, 0, 8, 255, 30) * glow;
        const size = BALL_SIZE + i * 6;
        fill(255, 255, 255, alpha);
        noStroke();
        ellipse(ball.x, ball.y, size);
    }
    
    // コア（真っ白な発光体）
    fill(255, 255, 255, 255 * glow);
    noStroke();
    ellipse(ball.x, ball.y, BALL_SIZE);
    
    // 内部ハイライト
    fill(255, 255, 255, 200 * glow);
    ellipse(ball.x - BALL_SIZE*0.15, ball.y - BALL_SIZE*0.15, BALL_SIZE * 0.4);
    
    pop();

    // ---- fogLayer を大きく消去して発光効果を演出 ----
    fogLayer.erase();
    fogLayer.fill(255);
    const CLEAR_SCALE = IS_MOBILE ? PD_SCALE : 1;
    const CLEAR_BALL_DIAM = (BALL_SIZE + 48) * CLEAR_SCALE * glow; // ボール半径分の発光クリア
    fogLayer.ellipse(ball.x, ball.y, CLEAR_BALL_DIAM);
    fogLayer.noErase();
}

function drawBallTrail() {
    // Draw trail effect that fades out over time
    push();
    
    for (let i = 0; i < ball.trail.length; i++) {
        let pos = ball.trail[i];
        let progress = i / (ball.trail.length - 1); // 0 to 1
        let alpha = map(progress, 0, 1, 0, 100); // Adjust fade from 0 to 100 for smoother transition
        // Comet-like taper: blend linear size with more aggressive pow-scaled size
        const sizeLinear = map(progress, 0, 1, 2, BALL_SIZE);
        const sizeComet = map(Math.pow(progress, 2), 0, 1, 2, BALL_SIZE); // sharper taper
        let size = lerp(sizeLinear, sizeComet, TRAIL_TAPER_INTENSITY);
        
        // ---- 白煙エフェクト : 全体の 20% 区間のみ描画 ----
        const smokeLen = Math.floor(ball.trail.length * 0.2);
        if (i < smokeLen) {
            let smokeProg = i / smokeLen; // 0(head)→1(tail)
            let smokeAlpha = map(smokeProg, 0, 1, 50, 0); // Adjust 20%→0% for smoother fade
            let smokeSize = map(smokeProg, 0, 1, size * 0.8, 2);
            // 30% だけ曇りを削る
            fogLayer.erase(255, smokeAlpha); // erase with partial alpha
            fogLayer.ellipse(pos.x, pos.y, smokeSize);
            fogLayer.noErase();
        }

        fogLayer.erase();
        fogLayer.fill(255);
        fogLayer.ellipse(pos.x, pos.y, size);
        fogLayer.noErase();
    }
    
    pop();
}

function checkLineCollisions(prevX, prevY) {
    for (let i = 0; i < lines.length; i++) {
        let lineData = lines[i];
        
        // Use smooth collision curve if available, otherwise fall back to original points
        let collisionPoints = lineData.collisionCurve || lineData.points;
        if (collisionPoints.length < 2) continue;
        
        // Check collision with each line segment of the smooth curve
        for (let j = 1; j < collisionPoints.length; j++) {
            let p1 = collisionPoints[j-1];
            let p2 = collisionPoints[j];
            
            // First check: current position distance
            let distance = distanceToLineSegment(ball.x, ball.y, p1.x, p1.y, p2.x, p2.y);
            
            // Second check: did the ball cross or come close between frames?
            let crossed = false;
            let pathDistance = Infinity;
            if (prevX !== undefined && prevY !== undefined) {
                crossed = lineSegmentsIntersect(prevX, prevY, ball.x, ball.y, p1.x, p1.y, p2.x, p2.y);
                // 追加: 移動線分と線分間の最短距離を計算
                pathDistance = distanceBetweenLineSegments(prevX, prevY, ball.x, ball.y, p1.x, p1.y, p2.x, p2.y);
            }
            
            if (distance <= COLLISION_RADIUS || crossed || pathDistance <= COLLISION_RADIUS) {
                // Collision detected!
                if (DEBUG) console.log('Collision detected with line', i);
                
                // Check if enough time has passed since last hit (500ms minimum)
                const currentTime = millis();
                const timeSinceLastHit = currentTime - lastHitTime;
                
                if (timeSinceLastHit < 500) {
                    if (DEBUG) console.log('Hit too soon, ignoring (', timeSinceLastHit, 'ms since last hit)');
                    // Reflect the ball but ensure it doesn't tunnel through
                    reflectBallOffLine(p1, p2, crossed, prevX, prevY);
                    return;
                }
                
                // Update hit timing
                lastHitTime = currentTime;
                
                // Check if this is the same line as last hit
                if (lastHitLineIndex === i) {
                    consecutiveHits++;
                } else {
                    consecutiveHits = 1; // Reset for new line
                    lastHitLineIndex = i;
                }
                
                if (DEBUG) console.log('Consecutive hits on line', i, ':', consecutiveHits);
                
                // Play sound with octave scaling
                if (typeof playLineSound === 'function') {
                    if (DEBUG) console.log('Calling playLineSound for line', i, 'with', lineData.points.length, 'points');
                    playLineSound(lineData, consecutiveHits, ball.x);
                } else {
                    console.error('playLineSound function not found');
                }
                
                // Create collision particles
                createCollisionParticles(ball.x, ball.y);
                
                // Add score (more points for consecutive hits)
                if (typeof addScore === 'function') {
                    addScore(lineData, 10 * consecutiveHits);
                }
                
                // Reflect ball off the line
                reflectBallOffLine(p1, p2, crossed, prevX, prevY);
                
                return; // Only handle one collision per frame
            }
        }
    }
    
    // Check collisions with hexagon points
    checkHexagonCollisions(prevX, prevY);
}

function checkHexagonCollisions(prevX, prevY) {
    for (let i = 0; i < points.length; i++) {
        let pointData = points[i];
        
        // Check collision with each edge of the hexagon
        for (let j = 0; j < pointData.vertices.length; j++) {
            let p1 = pointData.vertices[j];
            let p2 = pointData.vertices[(j + 1) % pointData.vertices.length]; // Next vertex (wrap around)
            
            // Check distance to this edge
            let distance = distanceToLineSegment(ball.x, ball.y, p1.x, p1.y, p2.x, p2.y);
            
            // Check if ball crossed this edge
            let crossed = false;
            let pathDistance = Infinity;
            if (prevX !== undefined && prevY !== undefined) {
                crossed = lineSegmentsIntersect(prevX, prevY, ball.x, ball.y, p1.x, p1.y, p2.x, p2.y);
                pathDistance = distanceBetweenLineSegments(prevX, prevY, ball.x, ball.y, p1.x, p1.y, p2.x, p2.y);
            }
            
            if (distance <= COLLISION_RADIUS || crossed || pathDistance <= COLLISION_RADIUS) {
                console.log('Collision detected with hexagon point', i, 'edge', j);
                
                // Check if enough time has passed since last hit
                const currentTime = millis();
                const timeSinceLastHit = currentTime - lastHitTime;
                
                if (timeSinceLastHit < 500) {
                    console.log('Hit too soon, ignoring');
                    reflectBallOffLine(p1, p2, crossed, prevX, prevY);
                    return;
                }
                
                lastHitTime = currentTime;
                consecutiveHits = 1; // Reset consecutive hits for points
                lastHitLineIndex = -1; // Reset line tracking
                
                // Play sound for hexagon hit (treat as a small line)
                if (typeof playLineSound === 'function') {
                    // Create a fake line data for sound calculation
                    let fakeLineData = {
                        points: [p1, p2],
                        startTime: pointData.startTime,
                        id: pointData.id
                    };
                    playLineSound(fakeLineData, 1, ball.x);
                }
                
                // Create collision particles for hexagon hit
                createCollisionParticles(ball.x, ball.y);
                
                // Add score for hitting point
                if (typeof addScore === 'function') {
                    addScore(pointData, 15); // Higher score for hitting points
                }
                
                // Reflect ball off the hexagon edge
                reflectBallOffLine(p1, p2, crossed, prevX, prevY);
                
                return; // Only handle one collision per frame
            }
        }
    }
}

function distanceToLineSegment(px, py, x1, y1, x2, y2) {
    // Calculate distance from point (px, py) to line segment (x1,y1)-(x2,y2)
    let A = px - x1;
    let B = py - y1;
    let C = x2 - x1;
    let D = y2 - y1;
    
    let dot = A * C + B * D;
    let lenSq = C * C + D * D;
    
    if (lenSq === 0) return Math.sqrt(A * A + B * B); // Point to point distance
    
    let param = dot / lenSq;
    
    let xx, yy;
    if (param < 0) {
        xx = x1;
        yy = y1;
    } else if (param > 1) {
        xx = x2;
        yy = y2;
    } else {
        xx = x1 + param * C;
        yy = y1 + param * D;
    }
    
    let dx = px - xx;
    let dy = py - yy;
    return Math.sqrt(dx * dx + dy * dy);
}

function lineSegmentsIntersect(x1, y1, x2, y2, x3, y3, x4, y4) {
    // Check if line segment (x1,y1)-(x2,y2) intersects with (x3,y3)-(x4,y4)
    let denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
    if (Math.abs(denom) < 0.0001) return false; // Lines are parallel
    
    let t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom;
    let u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denom;
    
    return (t >= 0 && t <= 1 && u >= 0 && u <= 1);
}

function generateSmoothCollisionCurve(originalPoints) {
    if (originalPoints.length < 3) return originalPoints;
    
    let smoothPoints = [];
    
    // Use a simple smoothing algorithm: average neighboring points
    // First point stays the same
    smoothPoints.push(originalPoints[0]);
    
    // Smooth middle points using weighted average
    for (let i = 1; i < originalPoints.length - 1; i++) {
        let prev = originalPoints[i - 1];
        let curr = originalPoints[i];
        let next = originalPoints[i + 1];
        
        // Weighted average: 25% previous + 50% current + 25% next
        let smoothX = prev.x * 0.25 + curr.x * 0.5 + next.x * 0.25;
        let smoothY = prev.y * 0.25 + curr.y * 0.5 + next.y * 0.25;
        
        smoothPoints.push({x: smoothX, y: smoothY});
    }
    
    // Last point stays the same
    smoothPoints.push(originalPoints[originalPoints.length - 1]);
    
    // Apply smoothing multiple times for better results (more passes)
    for (let pass = 0; pass < 3; pass++) {
        let tempPoints = [smoothPoints[0]]; // Keep first point
        
        for (let i = 1; i < smoothPoints.length - 1; i++) {
            let prev = smoothPoints[i - 1];
            let curr = smoothPoints[i];
            let next = smoothPoints[i + 1];
            
            let smoothX = prev.x * 0.2 + curr.x * 0.6 + next.x * 0.2;
            let smoothY = prev.y * 0.2 + curr.y * 0.6 + next.y * 0.2;
            
            tempPoints.push({x: smoothX, y: smoothY});
        }
        
        tempPoints.push(smoothPoints[smoothPoints.length - 1]); // Keep last point
        smoothPoints = tempPoints;
    }
    
    return smoothPoints;
}

// Add debug logging to track ball position and collision
console.log(`Ball position: (${ball.x.toFixed(2)}, ${ball.y.toFixed(2)})`);

// Refine collision handling
function reflectBallOffLine(p1, p2, crossed, prevX, prevY) {
    // Calculate line direction and normal (unit vectors)
    let lineVx = p2.x - p1.x;
    let lineVy = p2.y - p1.y;
    let lineLength = Math.sqrt(lineVx * lineVx + lineVy * lineVy);
    if (lineLength === 0) return;
    lineVx /= lineLength;
    lineVy /= lineLength;
    let normalX = -lineVy;
    let normalY = lineVx;

    // If we crossed the line, approximate intersection at midpoint between previous and current position
    if (crossed && prevX !== undefined && prevY !== undefined) {
        ball.x = (prevX + ball.x) * 0.5;
        ball.y = (prevY + ball.y) * 0.5;
    }

    // Determine correct normal orientation (pointing away from the line towards the ball)
    let side = (ball.x - p1.x) * normalX + (ball.y - p1.y) * normalY; // signed distance along normal
    if (side < 0) {
        // Flip normal to point outwards
        normalX *= -1;
        normalY *= -1;
        side *= -1;
    }

    // Move ball exactly outside the collision radius
    let distanceToLine = distanceToLineSegment(ball.x, ball.y, p1.x, p1.y, p2.x, p2.y);
    let penetration = COLLISION_RADIUS - distanceToLine;
    if (penetration > 0) {
        ball.x += normalX * (penetration + 0.1); // small epsilon
        ball.y += normalY * (penetration + 0.1);
    }

    // Reflect velocity
    let dotProduct = ball.vx * normalX + ball.vy * normalY;
    ball.vx = ball.vx - 2 * dotProduct * normalX;
    ball.vy = ball.vy - 2 * dotProduct * normalY;

    // Small damping to avoid endless vibration
    ball.vx *= 0.995;
    ball.vy *= 0.995;

    // Ensure minimum speed
    let speed = Math.hypot(ball.vx, ball.vy);
    if (speed < BALL_SPEED * 0.8) {
        ball.vx = (ball.vx / speed) * BALL_SPEED;
        ball.vy = (ball.vy / speed) * BALL_SPEED;
    }
}

// Drawing functions
function mousePressed() {
    // Initialize audio on first click
    handleUserInteraction();
    startDrawing(mouseX, mouseY);
}

function mouseDragged() {
    if (isDrawing) {
        addPointToCurrentLine(mouseX, mouseY);
    }
}

function mouseReleased() {
    endDrawing();
}

// Touch events for mobile
function touchStarted() {
    // Initialize audio on first touch
    handleUserInteraction();
    if (touches.length > 0) {
        startDrawing(touches[0].x, touches[0].y);
    }
    return false; // Prevent default
}

function touchMoved() {
    if (isDrawing && touches.length > 0) {
        addPointToCurrentLine(touches[0].x, touches[0].y);
    }
    return false; // Prevent default
}

function touchEnded() {
    endDrawing();
    return false; // Prevent default
}

function startDrawing(x, y) {
    isDrawing = true;
    currentLine = {
        points: [{x: x, y: y}],
        startTime: millis(),
        id: random(1000000) // Unique ID for scoring
    };
}

function addPointToCurrentLine(x, y) {
    if (!currentLine) return;
    
    let lastPoint = currentLine.points[currentLine.points.length - 1];
    let distance = dist(x, y, lastPoint.x, lastPoint.y);
    
    // Only add point if it's far enough from the last point
    if (distance > 3) {
        currentLine.points.push({x: x, y: y});
        
        // Limit line length
        if (currentLine.points.length > MAX_LINE_LENGTH) {
            currentLine.points.shift();
        }
    }
}

function endDrawing() {
    if (!isDrawing || !currentLine) return;
    
    isDrawing = false;
    
    // Check if it's a single click/tap (create point) or a line drag
    if (currentLine.points.length <= 2) {
        // Single click/tap - create a hexagon point
        createHexagonPoint(currentLine.points[0].x, currentLine.points[0].y);
    } else if (currentLine.points.length > 5) {
        // Line drag - create a line as before
        currentLine.collisionCurve = generateSmoothCollisionCurve(currentLine.points);
        
        lines.push({ points: currentLine.points, startTime: currentLine.startTime, id: currentLine.id, collisionCurve: currentLine.collisionCurve, clearDone: false });
        
        // Remove oldest line if we have too many
        if (lines.length > MAX_LINES) {
            lines.shift();
        }
    }
    
    currentLine = null;
}

function createHexagonPoint(x, y) {
    // Create a hexagon point with 6 vertices
    let hexagon = [];
    for (let i = 0; i < 6; i++) {
        let angle = (i * PI) / 3; // 60 degrees apart
        let px = x + cos(angle) * POINT_RADIUS;
        let py = y + sin(angle) * POINT_RADIUS;
        hexagon.push({x: px, y: py});
    }
    
    let point = {
        center: {x: x, y: y},
        vertices: hexagon,
        startTime: millis(),
        id: random(1000000)
    };
    
    points.push(point);
    
    // Remove oldest point if we have too many
    if (points.length > MAX_POINTS) {
        points.shift();
    }
    
    console.log('Created hexagon point at', x.toFixed(1), y.toFixed(1));
}

function updateLines() {
    let currentTime = millis();
    
    // Remove expired lines
    lines = lines.filter(lineData => {
        return currentTime - lineData.startTime < LINE_LIFETIME;
    });
    
    // Remove expired points
    points = points.filter(pointData => {
        return currentTime - pointData.startTime < POINT_LIFETIME;
    });
}

function drawLines() {
    push();

    // Draw all completed lines (perform one-time fog clear)
    for (let lineData of lines) {
        drawLine(lineData); // erase handled inside once
    }

    // Draw all hexagon points
    for (let pointData of points) {
        drawHexagonPoint(pointData);
    }

    pop();
}

function drawLine(lineData, doErase = true) {
    if (lineData.points.length < 2) return;
    
    const TAPER_PX = 40; // 約1cm
    const MIN_RATIO = 0.7; // 70% of main width

    // 線全体長を計算
    let totalLen = 0;
    for (let i = 1; i < lineData.points.length; i++) {
        totalLen += dist(lineData.points[i-1].x, lineData.points[i-1].y, lineData.points[i].x, lineData.points[i].y);
    }

    let accLen = 0;
    let currentTime = millis();
    let age = currentTime - lineData.startTime;
    let alpha = map(age, 0, LINE_LIFETIME, 255, 0);
    alpha = constrain(alpha, 0, 255);

    const needClear = doErase && !lineData.clearDone;

    for (let i = 1; i < lineData.points.length; i++) {
        let p1 = lineData.points[i-1];
        let p2 = lineData.points[i];
        let segLen = dist(p1.x, p1.y, p2.x, p2.y);

        // 距離ごとの太さ計算
        let midDist = accLen + segLen/2;
        let w;
        if (midDist < TAPER_PX) {
            w = map(midDist, 0, TAPER_PX, LINE_MAIN_WEIGHT * MIN_RATIO, LINE_MAIN_WEIGHT);
        } else if (midDist > totalLen - TAPER_PX) {
            w = map(midDist, totalLen - TAPER_PX, totalLen, LINE_MAIN_WEIGHT, LINE_MAIN_WEIGHT * MIN_RATIO);
        } else {
            w = LINE_MAIN_WEIGHT;
        }

        if (needClear) {
            fogLayer.erase(255, LINE_ERASE_ALPHA);
            try {
                fogLayer.stroke(255);
                fogLayer.strokeWeight(w * FOG_CLEAR_MULT * PD_SCALE);
                fogLayer.line(p1.x, p1.y, p2.x, p2.y);
            } finally {
                fogLayer.noErase();
            }
        }

        accLen += segLen;
    }

    // Mark clear done so subsequent frames don't keep erasing
    if (needClear) lineData.clearDone = true;
}

function drawHexagonPoint(pointData) {
    let currentTime = millis();
    let age = currentTime - pointData.startTime;
    let alpha = map(age, 0, POINT_LIFETIME, 255, 0);
    alpha = constrain(alpha, 0, 255);
    
    // Clear fog layer in circular shape (visual appearance)
    const SCALE = (IS_MOBILE ? PD_SCALE : 1);
    fogLayer.erase();
    fogLayer.fill(255);
    fogLayer.noStroke();
    
    // Draw circle instead of hexagon for visual appearance
    fogLayer.ellipse(pointData.center.x, pointData.center.y, POINT_RADIUS * 2);
    fogLayer.noErase();
}

function handleUserInteraction() {
    // Initialize audio context when user first interacts
    if (typeof initializeAudio === 'function') {
        initializeAudio();
    }
}

// Handle window resize
function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
    // 再生成: fogLayer サイズ調整
    fogLayer = createGraphics(windowWidth, windowHeight);
    fogLayer.noStroke();
    fogLayer.background(230, 230, 230, FOG_INITIAL_ALPHA); // 10% darker fog

    draftLayer = createGraphics(windowWidth, windowHeight);
    draftLayer.clear();
}

// 追加: 2つの線分間の最短距離を計算
function distanceBetweenLineSegments(x1, y1, x2, y2, x3, y3, x4, y4) {
    // エンドポイントと相手線分との距離の最小値を近似的に使用
    let d1 = distanceToLineSegment(x1, y1, x3, y3, x4, y4);
    let d2 = distanceToLineSegment(x2, y2, x3, y3, x4, y4);
    let d3 = distanceToLineSegment(x3, y3, x1, y1, x2, y2);
    let d4 = distanceToLineSegment(x4, y4, x1, y1, x2, y2);
    return Math.min(d1, d2, d3, d4);
}

// Expose to sound.js
if (typeof window !== 'undefined') {
    window.updateHitInfo = function(note, len, freq) {
        lastNoteName = note;
        lastLineLen = len;
        lastFreq = freq;
        lastInfoTime = millis();

        let noteEl = document.getElementById('note-display');
        if (!noteEl) {
            // Element missing (e.g., older HTML). Create on the fly.
            const container = document.getElementById('game-container') || document.body;
            noteEl = document.createElement('div');
            noteEl.id = 'note-display';
            noteEl.style.position = 'absolute';
            noteEl.style.top = '50px';
            noteEl.style.left = '20px';
            noteEl.style.color = 'white';
            noteEl.style.fontSize = '18px';
            noteEl.style.zIndex = '1000';
            noteEl.style.textShadow = '2px 2px 4px rgba(0,0,0,0.8)';
            container.appendChild(noteEl);
        }
        noteEl.textContent = `Note: ${note} | Len: ${len.toFixed(0)}px | ${freq.toFixed(1)}Hz`;

        console.log('HitInfo updated', note, len.toFixed(1), freq.toFixed(1));
    }
}

function fadeOutStartMessage() {
    const startMessage = document.getElementById('start-message');
    if (startMessage) {
        startMessage.style.transition = 'opacity 2s ease-out';
        startMessage.style.opacity = '0';
        setTimeout(() => {
            startMessage.style.display = 'none';
        }, 2000);
    }
}

// Call this function when the game starts
function startGame() {
    fadeOutStartMessage();
    // ... existing code to start the game ...
}

// Function to draw current line on preview layer without affecting fog
function drawPreviewLine(lineData) {
    console.log('drawPreviewLine called with points:', lineData.points.length);
    if (lineData.points.length < 2) return;

    // 一時的に背景をプレビューレイヤーにコピーして透明効果を表示
    draftLayer.clear(); // プレビュー開始時にクリア
    draftLayer.push();
    console.log('draftLayer cleared and starting preview draw');
    
    // 背景画像があれば描画
    if (backgroundImg) {
        // 縦横比を保持して背景画像を描画
        let imgAspect = backgroundImg.width / backgroundImg.height;
        let canvasAspect = width / height;
        
        let drawWidth, drawHeight, drawX, drawY;
        
        if (imgAspect > canvasAspect) {
            // 画像の方が横長：高さを基準に
            drawHeight = height;
            drawWidth = height * imgAspect;
            drawX = (width - drawWidth) / 2;
            drawY = 0;
        } else {
            // 画像の方が縦長：幅を基準に
            drawWidth = width;
            drawHeight = width / imgAspect;
            drawX = 0;
            drawY = (height - drawHeight) / 2;
        }
        
        draftLayer.image(backgroundImg, drawX, drawY, drawWidth, drawHeight);
    }
    
    // 現在の霧レイヤーをコピーしてプレビュー線で削る
    draftLayer.tint(255, 255);
    draftLayer.image(fogLayer, 0, 0);
    draftLayer.noTint();
    
    // プレビュー線を描画（透明効果）
    draftLayer.erase(255, LINE_ERASE_ALPHA);
    draftLayer.stroke(255);
    draftLayer.noFill();
    
    const TAPER_PX = 40;
    let totalLen = 0;
    for (let i = 1; i < lineData.points.length; i++) {
        totalLen += dist(lineData.points[i-1].x, lineData.points[i-1].y, lineData.points[i].x, lineData.points[i].y);
    }
    
    let accLen = 0;
    for (let i = 1; i < lineData.points.length; i++) {
        let p1 = lineData.points[i-1];
        let p2 = lineData.points[i];
        let segLen = dist(p1.x, p1.y, p2.x, p2.y);
        
        let midDist = accLen + segLen/2;
        let w;
        if (midDist < TAPER_PX) {
            w = map(midDist, 0, TAPER_PX, LINE_MAIN_WEIGHT * 0.7, LINE_MAIN_WEIGHT);
        } else if (midDist > totalLen - TAPER_PX) {
            w = map(midDist, totalLen - TAPER_PX, totalLen, LINE_MAIN_WEIGHT, LINE_MAIN_WEIGHT * 0.7);
        } else {
            w = LINE_MAIN_WEIGHT;
        }
        
        draftLayer.strokeWeight(w);
        draftLayer.line(p1.x, p1.y, p2.x, p2.y);
        
        accLen += segLen;
    }
    
    draftLayer.noErase();
    draftLayer.pop();
}

function drawPreviewLineDirectly(lineData) {
    if (lineData.points.length < 2) return;
    
    // 霧レイヤーに直接一時的に透明効果を描画
    fogLayer.push();
    fogLayer.erase(255, LINE_ERASE_ALPHA * 0.7); // プレビューは少し薄めに
    
    const TAPER_PX = 40;
    let totalLen = 0;
    for (let i = 1; i < lineData.points.length; i++) {
        totalLen += dist(lineData.points[i-1].x, lineData.points[i-1].y, lineData.points[i].x, lineData.points[i].y);
    }
    
    let accLen = 0;
    for (let i = 1; i < lineData.points.length; i++) {
        let p1 = lineData.points[i-1];
        let p2 = lineData.points[i];
        let segLen = dist(p1.x, p1.y, p2.x, p2.y);
        
        let midDist = accLen + segLen/2;
        let w;
        if (midDist < TAPER_PX) {
            w = map(midDist, 0, TAPER_PX, LINE_MAIN_WEIGHT * 0.7, LINE_MAIN_WEIGHT);
        } else if (midDist > totalLen - TAPER_PX) {
            w = map(midDist, totalLen - TAPER_PX, totalLen, LINE_MAIN_WEIGHT, LINE_MAIN_WEIGHT * 0.7);
        } else {
            w = LINE_MAIN_WEIGHT;
        }
        
        fogLayer.stroke(255);
        fogLayer.strokeWeight(w);
        fogLayer.line(p1.x, p1.y, p2.x, p2.y);
        
        accLen += segLen;
    }
    
    fogLayer.noErase();
    fogLayer.pop();
} 